package com.custom.jwt.jwtauth.service;
import java.util.ArrayList;

import com.custom.jwt.jwtauth.model.User;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


@Service
public class JwtUserDetailsServiceImpl implements JwtUserDetailsService {

	@Autowired
	private PasswordEncoder bCryptPasswordEncoder;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	
		return new org.springframework.security.core.userdetails.User(user.getUsername(), bCryptPasswordEncoder.encode(user.getPassword()),
				new ArrayList<>());
		/*if ("javainuse".equals(username)) {
			
		} else {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}*/
	}
	
	private User user;

	public User getUser() {
		return user;
	}
	@Override
	public void setUser(User user) {
		this.user = user;
	}



}
