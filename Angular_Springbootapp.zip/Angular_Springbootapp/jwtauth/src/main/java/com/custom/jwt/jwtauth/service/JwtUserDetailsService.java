package com.custom.jwt.jwtauth.service;
import java.util.ArrayList;

import com.custom.jwt.jwtauth.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public interface JwtUserDetailsService extends UserDetailsService {
	public void setUser(User user);
}
