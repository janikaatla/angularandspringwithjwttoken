package com.custom.jwt.jwtauth.util;


import com.custom.jwt.jwtauth.model.Role;
import com.custom.jwt.jwtauth.model.User;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class AppUsersService {

    public User connectUserService(String username, String password){
        if (username != null && username.length()>5) {
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            Role role = new Role();
            role.setRolename("USER");
            List<Role> roles = new ArrayList<Role>();
            roles.add(role);
            user.setAuthorities(roles);
            user.setDisplayName("Janaiah Kaatla");
            user.setDepartment("Dev");
            user.setMail("janaiah.kaatla@our.com");
            return user;
        } else {
            return null;
        }

    }

}
