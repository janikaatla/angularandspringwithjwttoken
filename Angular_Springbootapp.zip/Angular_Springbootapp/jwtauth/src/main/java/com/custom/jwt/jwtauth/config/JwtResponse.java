package com.custom.jwt.jwtauth.config;
import com.custom.jwt.jwtauth.model.User;

import java.io.Serializable;

public class JwtResponse implements Serializable {

    private static final long serialVersionUID = -8091879091924046844L;
    private final String jwttoken;

    private final User jwtUsertoken;

    public JwtResponse(final String jwttoken) {
        this.jwttoken = jwttoken;
        this.jwtUsertoken=null;
    }

    public JwtResponse(final User jwttoken) {
        this.jwtUsertoken = jwttoken;
        this.jwttoken =null;
    }

    public User getUserToken() {
        return this.jwtUsertoken;
    }

    public String getErrorToken() {
        return this.jwttoken;
    }
}
