import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itemmenutwo',
  templateUrl: './itemmenutwo.component.html',
  styleUrls: ['./itemmenutwo.component.scss']
})
export class ItemmenutwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
