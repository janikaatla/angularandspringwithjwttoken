import { BrowserModule } from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatSidenavModule} from "@angular/material/sidenav";
import {MatIconModule} from "@angular/material/icon";
import {MatButtonModule} from "@angular/material/button";
import {MatTabsModule} from "@angular/material/tabs";
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatAutocompleteModule} from "@angular/material/autocomplete";
import {MatSelectModule} from "@angular/material/select";
import {MatDialogModule} from "@angular/material/dialog";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {MatButtonToggleModule} from "@angular/material/button-toggle";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatSlideToggleModule} from "@angular/material/slide-toggle";
import {MatListModule} from "@angular/material/list";
import {MatToolbarModule} from "@angular/material/toolbar";
import {MatNativeDateModule} from "@angular/material/core";
import {MatMenuModule} from '@angular/material/menu';
import { LayoutComponent } from './appConfigs/layout/layout.component';
import { TabComponent } from './appConfigs/tab/tab.component';
import { LoaderComponent } from './appConfigs/loader/loader.component';
import {TabContentComponent} from "./appConfigs/tab/TabContentComponent";
import {ContentContainerDirective} from "./appConfigs/tab/ContentContainerDirective";
import { LoginComponent } from './appConfigs/login/login.component';
import { ItemmenuComponent } from './moduleone/itemmenu/itemmenu.component';
import { ItemmenutwoComponent } from './moduleone/itemmenutwo/itemmenutwo.component';
import {SpinnerOverlayService} from "./appServices/spinner-overlay.service";
import {Overlay} from "@angular/cdk/overlay";
import {AgGridModule} from "ag-grid-angular";
import {TabService} from "./appServices/tab.service";
import {HttpClientModule} from "@angular/common/http";
import {ReactiveFormsModule} from "@angular/forms";

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    TabComponent,
    TabContentComponent,
    ContentContainerDirective,
    LoaderComponent,
    LoginComponent,
    ItemmenuComponent,
    ItemmenutwoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    MatTabsModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDialogModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatListModule,
    MatToolbarModule,
    MatMenuModule,
    ReactiveFormsModule
  ],
  providers: [
    SpinnerOverlayService,
    Overlay,
    TabService
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule { }
