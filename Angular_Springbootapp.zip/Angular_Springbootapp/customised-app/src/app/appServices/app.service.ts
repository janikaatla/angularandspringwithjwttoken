import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {environment} from "../../environments/environment";
import {LoadingOverlayRef, SpinnerOverlayService} from "./spinner-overlay.service";
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class AppService {
  private _url = environment.url+"/authenticate";
  private loadingRef: LoadingOverlayRef | undefined;

  constructor(private http: HttpClient, private router: Router, private spinnerOverlayService: SpinnerOverlayService) { }
  showLoader() {
    console.log("start loader called");
    this.loadingRef = this.spinnerOverlayService.open();
  }

  hideLoader() {
    console.log("end loader called");
    if (this.loadingRef) {
      this.loadingRef.close();
    }
  }

  authenticate(username: string, password: string) {
    return this.http.post<any>(this._url,{"username": username,"password":password}).pipe(
      map(
        userData => {
          sessionStorage.setItem('username',username);
          let tokenStr= 'Bearer '+userData.token;
          console.log(tokenStr);
          sessionStorage.setItem('displayName', userData.username);
          sessionStorage.setItem('token', tokenStr);
          return userData;
        }
      )
    );
  }

  login(username: string, password: string)  {
    // alert("username : "+username);
    // var userpass="'"+username+":"+password+"'";
    return this.http.post<any>(this._url, {username,password});

  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    //console.log(!(user === null))
    return !(user === null)
  }
  logOut() {
    sessionStorage.removeItem('username')
  }
}
