import { Injectable } from '@angular/core';
import {Tab} from "../model/tab.model";
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class TabService {

  private exist = false;
  private currentTabIndex: number | undefined;
  public tabs: Tab[] = [];
  public tabSub = new BehaviorSubject<Tab[]>(this.tabs);
  public removeTab(index: number) {
    this.tabs.splice(index, 1);
    if (this.tabs.length > 0) {
      this.tabs[this.tabs.length - 1].active = true;
      this.currentTabIndex = this.tabs.length - 1;
      this.tabSub.next(this.tabs);
      // this.tabSub = new BehaviorSubject<Tab[]>(this.tabs);
    }

  }

  public addTab(tab: Tab) {
    this.exist = false;
    // tslint:disable-next-line:prefer-for-of
    console.log("this.tabs.length " + this.tabs.length);
    for (let i = 0; i < this.tabs.length; i++) {
      if (this.tabs[i].active === true) {
        this.tabs[i].active = false;
      }
      if (this.tabs[i].title === tab.title) {
        this.exist = true;
      }
    }
    console.log("this.exist " + this.exist);
    if (!this.exist) {
      // tslint:disable-next-line:prefer-for-of
      // tab.id = this.tabs.length + 1;
      tab.active = true;
      this.currentTabIndex = this.tabs.length;
      this.tabs.push(tab);
      console.log("after push " + this.tabs.length);
      this.tabSub.next(this.tabs);
      // this.tabSub = new BehaviorSubject<Tab[]>(this.tabs);;
      console.log("after tabSub push " + this.tabs.length);
    } else {
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < this.tabs.length; i++) {
        if (this.tabs[i].uniqueId === tab.uniqueId) {
          this.tabs[i].active = true;
          this.currentTabIndex = i;
        }
      }
      this.tabSub.next(this.tabs);
      // this.tabSub = new BehaviorSubject<Tab[]>(this.tabs);;
    }
  }

  getTabSub() {
    this.tabSub.next(this.tabs);
  }


  public isEmptyObject(obj: {}) {
    return (obj && (Object.keys(obj).length === 0));
  }

  public isEmpty(obj: { hasOwnProperty: (arg0: string) => any; }) {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        return false;
      }
    }
    return true;
  }

  public getCurrentIndex() {
    return this.currentTabIndex;
  }

  public presentTabIndex(index: number | undefined) {
    this.currentTabIndex = index;
    if (this.tabs.length > 0) {
      for (let i = 0; i < this.tabs.length; i++) {
        this.tabs[i].active = false;
      }
      // @ts-ignore
      this.tabs[this.currentTabIndex].active = true;

    }
  }

  public presentTabUniqueValue() {
    // @ts-ignore
    return this.tabs[this.currentTabIndex].uniqueId;
  }
  public presentTabFilePath() {
    // @ts-ignore
    return this.tabs[this.currentTabIndex].batchID;
  }

  public getBatchInfoId() {
    // @ts-ignore
    return this.tabs[this.currentTabIndex].batchInfoId;
  }

  public getBatchId() {
    // @ts-ignore
    return this.tabs[this.currentTabIndex].batchId;
  }
}
