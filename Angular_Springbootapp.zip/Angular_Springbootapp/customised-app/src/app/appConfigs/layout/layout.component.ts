import { Component, OnInit } from '@angular/core';
import {ItemmenuComponent} from "../../moduleone/itemmenu/itemmenu.component";
import {Tab} from "../../model/tab.model";
import {Router} from "@angular/router";
import {TabService} from "../../appServices/tab.service";
import {ItemmenutwoComponent} from "../../moduleone/itemmenutwo/itemmenutwo.component";

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {
  currentUser: string | null='';
  constructor(private router: Router, private tabService: TabService) {
  }

  ngOnInit(): void {
    this.currentUser=sessionStorage.getItem('displayName');
  }

  sampleitem1() {
    const tab = new Tab(ItemmenuComponent, 'Sample Items one', { parent: 'TabComponent' });
    tab.id = 0;
    tab.uniqueId = 0;
    this.tabService.addTab(tab);
  }

  sampleitem2() {
    const tab = new Tab(ItemmenutwoComponent, 'Sample Items two', { parent: 'TabComponent' });
    tab.id = 0;
    tab.uniqueId = 0;
    this.tabService.addTab(tab);
  }

  logout() {
    sessionStorage.removeItem('displayName');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('token');
    sessionStorage.setItem('logout', 'appOut');
    this.router.navigate(['/']);
    return false;
  }

}
