import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {AppService} from "../../appServices/app.service";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;

  constructor(private formBuilder: FormBuilder,
              private route: ActivatedRoute,private router: Router,
              private appService: AppService) {
    this.loginForm= this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {

  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted=false;
    this.appService.showLoader();
  // @ts-ignore
    this.appService.login(this.f.username.value, this.f.password.value).subscribe(response =>{
        if (response.errorToken != null && response.errorToken!='') {

          // alert(response.errorToken);
          return false;
        } else {
          this.handleSuccessfulResponse(response)
          sessionStorage.setItem('username',this.f.username.value);
          this.router.navigate(["layout"]);
        }
        this.appService.hideLoader();
      },
      error => {
        this.appService.hideLoader();
        //this.alertService.error(error);
        // this.loading = false;
      });


  }

  handleSuccessfulResponse(response: any) {
    // alert(response.userToken.token);

    let tokenStr= 'Bearer '+response.userToken.token;
    sessionStorage.setItem('token', tokenStr);
    console.log(tokenStr);
    sessionStorage.setItem('displayName', response.userToken.username);
    //return userData;
    //this.userComponent.employees=response;
    //this.router.navigate(["user"]);
  }

}
