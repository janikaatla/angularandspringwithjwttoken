import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewEncapsulation} from '@angular/core';
import {Tab} from "../../model/tab.model";
import {TabService} from "../../appServices/tab.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TabComponent implements OnInit {
  tabs = new Array<Tab>();
  selectedTab: number | undefined;

  constructor(private tabService: TabService,private router: Router, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    if (sessionStorage.getItem('logout') !== null && sessionStorage.getItem('logout') !== 'logOut') {
      sessionStorage.removeItem('logout');
      location.reload();
    } else {
      if (sessionStorage.getItem('displayName') !== null && sessionStorage.getItem('displayName') !== '') {
        this.tabService.tabSub.subscribe(tabs => {
          this.tabs = tabs;

          this.selectedTab = tabs.findIndex(tab => tab.active);
        });
      } else {
        alert('Session expired! please login again!!');
        this.router.navigate(['/']);
      }
    }
  }

  tabChanged(event: { index: number; }) {
    this.selectedTab = event.index;
    console.log('this.selectedTab : '+ this.selectedTab);
    this.tabService.presentTabIndex(event.index);
  }

  removeTab(index: number): void {
    this.tabService.removeTab(index);
  }

  clickedTab(index: number): void {
    this.tabService.removeTab(index);
  }

  ngAfterContentChecked() {
    // console.log("ngAfterContentChanged")
    this.cdr.detectChanges();
  }

}
