import {
  Component,
  Input,
  ComponentFactoryResolver,
  ViewChild,
  OnInit
} from '@angular/core';
import {ContentContainerDirective} from './ContentContainerDirective';
import {SkeletonComponent} from './SkeletonComponent';
import {Tab} from "../../model/tab.model";


@Component({
  selector: 'app-tab-content',
  template: '<ng-template content-container></ng-template>'
})
export class TabContentComponent implements OnInit {
  @Input() tab: Tab | undefined;
  @ViewChild(ContentContainerDirective, { static: true })
  contentContainer: ContentContainerDirective | undefined;

  constructor(private componentFactoryResolver: ComponentFactoryResolver) {}

  ngOnInit() {
    if(this.tab != undefined && this.contentContainer != undefined) {

      const componentFactory = this.componentFactoryResolver.resolveComponentFactory(
        this.tab.component
      );
      const viewContainerRef = this.contentContainer.viewContainerRef;
      const componentRef = viewContainerRef.createComponent(componentFactory);
      (componentRef.instance as SkeletonComponent).data = this.tab.tabData;
    }
  }
}
