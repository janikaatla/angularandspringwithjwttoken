import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LayoutComponent} from "./appConfigs/layout/layout.component";
import {TabComponent} from "./appConfigs/tab/tab.component";
import { LoginComponent } from './appConfigs/login/login.component';

const routes: Routes = [
  {path: '', component: LoginComponent},
  {
    path: 'layout',
    component: LayoutComponent,
    data: {
      title: 'Home',
    },
    children: [
      {
        path: '',
        redirectTo: 'tab',
        pathMatch: 'full'
      },
      {
        path: 'tab',
        component: TabComponent
      }]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
